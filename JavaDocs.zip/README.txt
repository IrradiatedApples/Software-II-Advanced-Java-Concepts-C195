WGU Software II - Advanced Java Concepts – C195
GUI-Based Scheduling Desktop Application

This application is designed to showcase advanced Java skills.
The application provides a GUI to add, update, and delete
Customers and Appointments from a MySQL database.
Additionally, it provides three reports.

How to use:
After launching the application provide a User ID(test) and Password(test). You may login by selcting the login button or hitting 'Enter' when in one of the two text fields.

With successful login a popup will appear informing you of any appointment starting within 15 minutes.

Navigate using the buttons on the left:
Appointments
-Displays all appoinments
-Can filter appointments by All, this Month, or this Week
-May Add, Update, or Delete appointments
-All appointments must be scheduled within buisness hours
 Monday through Friday, 8:00 a.m. to 10:00 p.m. Eastern Time
-No appoitments may overlap for any given user

Customers
-Displays all customers
-May Add, Update, or Delete customers
--When a customer is deleted all of their appointments are
  also deleted

Reports
-Report One, # of Appointments by Month and Type
-Report Two, Appointment Schedule of selcted Contact
-Report Three, Total appointment hours per Customer

Exit
Closes the application

Created by:
Arthur J. Amende
#002180137
(509) 398 5020
Pacific Time Zone
aamende@wgu.edu
10/14/2021

Version 1.0

Developed with:
IntelliJ Community 2021.1.3
Java 8 Update 301
JavaFX-SDK-11.0.2
mysql-connector-java-8.0.26

